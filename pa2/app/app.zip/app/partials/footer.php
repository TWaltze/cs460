<footer class="footer">
    <div class="container">
        &copy; <?php echo date("Y"); ?> Tyler Waltze
    </div>
</footer>
