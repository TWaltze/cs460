<?php
require_once($_SERVER['DOCUMENT_ROOT'] . "/lib/models/Auth.php");
Auth::logout();
?>
